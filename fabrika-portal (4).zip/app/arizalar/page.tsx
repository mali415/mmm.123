"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { format } from "date-fns"
import { tr } from "date-fns/locale"
import { CalendarIcon, Plus, Search, MoreHorizontal, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { Checkbox } from "@/components/ui/checkbox"

// Form şeması
const arizaFormSchema = z.object({
  tesisId: z.string({
    required_error: "Lütfen bir tesis seçin.",
  }),
  ekipmanId: z.string({
    required_error: "Lütfen bir ekipman seçin.",
  }),
  arizaTuru: z.string({
    required_error: "Lütfen arıza türünü seçin.",
  }),
  oncelik: z.string({
    required_error: "Lütfen öncelik seviyesini seçin.",
  }),
  aciklama: z.string().min(10, {
    message: "Açıklama en az 10 karakter olmalıdır.",
  }),
  bildirimTarihi: z.date({
    required_error: "Lütfen bildirim tarihini seçin.",
  }),
})

// Örnek arıza verileri
const arizalar = [
  {
    id: "ARZ-2023-001",
    tesisAdi: "Tesis 1",
    ekipmanAdi: "Üretim Hattı A - Konveyör",
    arizaTuru: "Mekanik",
    bildirimTarihi: "2023-05-15T09:30:00",
    durum: "Çözüldü",
    oncelik: "Yüksek",
    atananKisi: "Ahmet Yılmaz",
    aciklama: "Konveyör bandı sık sık duruyor ve üretimi aksatıyor.",
    cozumNotu: "Konveyör motoru değiştirildi ve sistem yeniden kalibre edildi.",
  },
  {
    id: "ARZ-2023-002",
    tesisAdi: "Tesis 2",
    ekipmanAdi: "Paketleme Ünitesi",
    arizaTuru: "Elektrik",
    bildirimTarihi: "2023-05-18T14:15:00",
    durum: "İşlemde",
    oncelik: "Orta",
    atananKisi: "Mehmet Demir",
    aciklama: "Paketleme ünitesinde elektrik kesintileri yaşanıyor.",
    cozumNotu: "",
  },
  {
    id: "ARZ-2023-003",
    tesisAdi: "Tesis 1",
    ekipmanAdi: "Kompresör Ünitesi",
    arizaTuru: "Hidrolik",
    bildirimTarihi: "2023-05-20T11:45:00",
    durum: "Beklemede",
    oncelik: "Düşük",
    atananKisi: "",
    aciklama: "Kompresör ünitesinde basınç düşüşü var.",
    cozumNotu: "",
  },
  {
    id: "ARZ-2023-004",
    tesisAdi: "Tesis 3",
    ekipmanAdi: "Soğutma Sistemi",
    arizaTuru: "Mekanik",
    bildirimTarihi: "2023-05-22T08:30:00",
    durum: "İncelemede",
    oncelik: "Kritik",
    atananKisi: "Ali Kaya",
    aciklama: "Soğutma sistemi çalışmıyor, üretim durma noktasında.",
    cozumNotu: "",
  },
  {
    id: "ARZ-2023-005",
    tesisAdi: "Tesis 2",
    ekipmanAdi: "Karıştırıcı Tank",
    arizaTuru: "Sensör",
    bildirimTarihi: "2023-05-25T16:20:00",
    durum: "Çözüldü",
    oncelik: "Yüksek",
    atananKisi: "Ayşe Yıldız",
    aciklama: "Karıştırıcı tankın sıcaklık sensörü hatalı değerler veriyor.",
    cozumNotu: "Sensör değiştirildi ve kalibrasyon yapıldı.",
  },
]

// Örnek tesisler
const tesisler = [
  { id: "1", ad: "Tesis 1" },
  { id: "2", ad: "Tesis 2" },
  { id: "3", ad: "Tesis 3" },
]

// Örnek ekipmanlar
const ekipmanlar = [
  { id: "1", tesisId: "1", ad: "Üretim Hattı A - Konveyör" },
  { id: "2", tesisId: "1", ad: "Kompresör Ünitesi" },
  { id: "3", tesisId: "1", ad: "Karıştırıcı Tank 1" },
  { id: "4", tesisId: "2", ad: "Paketleme Ünitesi" },
  { id: "5", tesisId: "2", ad: "Karıştırıcı Tank" },
  { id: "6", tesisId: "2", ad: "Üretim Hattı B" },
  { id: "7", tesisId: "3", ad: "Soğutma Sistemi" },
  { id: "8", tesisId: "3", ad: "Üretim Hattı C" },
  { id: "9", tesisId: "3", ad: "Depolama Ünitesi" },
]

// Arıza türleri
const arizaTurleri = ["Mekanik", "Elektrik", "Elektronik", "Hidrolik", "Pnömatik", "Sensör", "Yazılım", "Diğer"]

// Öncelik seviyeleri
const oncelikSeviyeleri = [
  { id: "kritik", ad: "Kritik", renk: "destructive" },
  { id: "yuksek", ad: "Yüksek", renk: "destructive" },
  { id: "orta", ad: "Orta", renk: "warning" },
  { id: "dusuk", ad: "Düşük", renk: "secondary" },
]

// Durum seviyeleri
const durumSeviyeleri = [
  { id: "beklemede", ad: "Beklemede", renk: "secondary" },
  { id: "incelemede", ad: "İncelemede", renk: "warning" },
  { id: "islemde", ad: "İşlemde", renk: "warning" },
  { id: "cozuldu", ad: "Çözüldü", renk: "success" },
  { id: "iptal", ad: "İptal", renk: "destructive" },
]

// Personel listesi
const personel = [
  { id: "1", ad: "Ahmet Yılmaz", unvan: "Teknisyen" },
  { id: "2", ad: "Mehmet Demir", unvan: "Teknisyen" },
  { id: "3", ad: "Ali Kaya", unvan: "Mühendis" },
  { id: "4", ad: "Ayşe Yıldız", unvan: "Teknisyen" },
  { id: "5", ad: "Hasan Şahin", unvan: "Mühendis" },
]

// Bakım türleri
const bakimTurleri = ["Periyodik Bakım", "Koruyucu Bakım", "Kestirimci Bakım", "Düzeltici Bakım", "Acil Bakım"]

// Örnek malzemeler
const malzemeler = [
  { id: "M001", ad: "Yağlama Kiti", stok: 15, birim: "Adet" },
  { id: "M002", ad: "Filtre Seti", stok: 8, birim: "Adet" },
  { id: "M003", ad: "Sensör Modülü", stok: 5, birim: "Adet" },
  { id: "M004", ad: "Conta Takımı", stok: 20, birim: "Set" },
  { id: "M005", ad: "Motor Kayışı", stok: 12, birim: "Adet" },
  { id: "M006", ad: "Rulman", stok: 30, birim: "Adet" },
  { id: "M007", ad: "Hidrolik Yağ", stok: 50, birim: "Litre" },
]

export default function ArizalarPage() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("tum-arizalar")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedAriza, setSelectedAriza] = useState(null)
  const [isCompletionDialogOpen, setIsCompletionDialogOpen] = useState(false)
  const [filteredEkipmanlar, setFilteredEkipmanlar] = useState([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("tumu")
  const [priorityFilter, setPriorityFilter] = useState("tumu")
  const [selectedFile, setSelectedFile] = useState(null)
  const [isBakimDialogOpen, setIsBakimDialogOpen] = useState(false)
  const [isArizaDialogOpen, setIsArizaDialogOpen] = useState(false)
  const [selectedMalzemeler, setSelectedMalzemeler] = useState([])

  const form = useForm({
    resolver: zodResolver(arizaFormSchema),
    defaultValues: {
      tesisId: "",
      ekipmanId: "",
      arizaTuru: "",
      oncelik: "",
      aciklama: "",
      bildirimTarihi: new Date(),
    },
  })

  // Tesis değiştiğinde ekipmanları filtrele
  const handleTesisChange = (tesisId) => {
    form.setValue("tesisId", tesisId)
    form.setValue("ekipmanId", "")
    const filtered = ekipmanlar.filter((ekipman) => ekipman.tesisId === tesisId)
    setFilteredEkipmanlar(filtered)
  }

  // Arıza detayını göster
  const handleShowDetail = (ariza) => {
    setSelectedAriza(ariza)
  }

  // Arıza formu gönderimi
  const onSubmit = (data) => {
    setIsSubmitting(true)

    // Simüle edilmiş form gönderimi
    setTimeout(() => {
      console.log("Form verileri:", data)
      console.log("Seçilen dosya:", selectedFile)

      toast({
        title: "Arıza bildirimi oluşturuldu",
        description: "Arıza bildirimi başarıyla kaydedildi.",
      })

      form.reset()
      setSelectedFile(null)
      setIsDialogOpen(false)
      setIsSubmitting(false)
    }, 1500)
  }

  // Dosya seçimi
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0])
    }
  }

  // Filtreleme fonksiyonu
  const filteredArizalar = arizalar.filter((ariza) => {
    // Arama terimi filtresi
    const searchMatch =
      ariza.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ariza.tesisAdi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ariza.ekipmanAdi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ariza.aciklama.toLowerCase().includes(searchTerm.toLowerCase())

    // Durum filtresi
    const statusMatch = statusFilter === "tumu" || ariza.durum.toLowerCase() === statusFilter.toLowerCase()

    // Öncelik filtresi
    const priorityMatch = priorityFilter === "tumu" || ariza.oncelik.toLowerCase() === priorityFilter.toLowerCase()

    return searchMatch && statusMatch && priorityMatch
  })

  // Durum badgesi render fonksiyonu
  const renderStatusBadge = (status) => {
    const durumSeviye = durumSeviyeleri.find((d) => d.ad.toLowerCase() === status.toLowerCase())

    if (!durumSeviye) return <Badge>{status}</Badge>

    return <Badge variant={durumSeviye.renk}>{status}</Badge>
  }

  // Öncelik badgesi render fonksiyonu
  const renderPriorityBadge = (priority) => {
    const oncelikSeviye = oncelikSeviyeleri.find((o) => o.ad.toLowerCase() === priority.toLowerCase())

    if (!oncelikSeviye) return <Badge>{priority}</Badge>

    return <Badge variant={oncelikSeviye.renk}>{priority}</Badge>
  }

  // Bakım planlama işlevi
  const handlePlanMaintenance = (ariza) => {
    setSelectedAriza(ariza)
    setIsBakimDialogOpen(true)
  }

  // Bakım planlama form gönderimi
  const handleBakimSubmit = (e) => {
    e.preventDefault()

    // Seçilen malzemeleri kontrol et
    if (selectedMalzemeler.length > 0) {
      // Envanter güncellemesi
      const updatedMalzemeler = malzemeler.map((malzeme) => {
        const selectedMalzeme = selectedMalzemeler.find((sm) => sm.id === malzeme.id)
        if (selectedMalzeme) {
          return {
            ...malzeme,
            stok: malzeme.stok - selectedMalzeme.miktar,
          }
        }
        return malzeme
      })

      console.log("Güncellenen envanter:", updatedMalzemeler)
    }

    toast({
      title: "Bakım planlanıyor",
      description: `${selectedAriza.id} - ${selectedAriza.ekipmanAdi} için bakım planlanıyor.`,
    })

    // Simüle edilmiş işlem
    setTimeout(() => {
      toast({
        title: "Bakım planlandı",
        description: `${selectedAriza.id} - ${selectedAriza.ekipmanAdi} için bakım başarıyla planlandı.${selectedMalzemeler.length > 0 ? " Malzemeler envanterden düşüldü." : ""}`,
      })
      setIsBakimDialogOpen(false)
      setSelectedMalzemeler([])
    }, 1500)
  }

  // Malzeme seçimi işlevi
  const handleMalzemeChange = (malzemeId, miktar) => {
    setSelectedMalzemeler((prev) => {
      // Eğer malzeme zaten seçiliyse, miktarını güncelle
      const existingIndex = prev.findIndex((item) => item.id === malzemeId)

      if (existingIndex >= 0) {
        // Miktar 0 ise malzemeyi listeden çıkar
        if (miktar === 0) {
          return prev.filter((item) => item.id !== malzemeId)
        }

        // Miktarı güncelle
        const updated = [...prev]
        updated[existingIndex] = { ...updated[existingIndex], miktar }
        return updated
      } else if (miktar > 0) {
        // Yeni malzeme ekle
        const malzeme = malzemeler.find((m) => m.id === malzemeId)
        return [...prev, { id: malzemeId, ad: malzeme.ad, miktar, birim: malzeme.birim }]
      }

      return prev
    })
  }

  // Arıza tamamlama form gönderimi
  const handleCompletionSubmit = (e) => {
    e.preventDefault()

    // Seçilen malzemeleri kontrol et
    if (selectedMalzemeler.length > 0) {
      // Envanter güncellemesi
      const updatedMalzemeler = malzemeler.map((malzeme) => {
        const selectedMalzeme = selectedMalzemeler.find((sm) => sm.id === malzeme.id)
        if (selectedMalzeme) {
          return {
            ...malzeme,
            stok: malzeme.stok - selectedMalzeme.miktar,
          }
        }
        return malzeme
      })

      console.log("Güncellenen envanter:", updatedMalzemeler)
    }

    toast({
      title: "Arıza çözümü kaydediliyor",
      description: `${selectedAriza.id} ID'li arıza çözümü kaydediliyor.`,
    })

    // Simüle edilmiş tamamlama işlemi
    setTimeout(() => {
      toast({
        title: "Arıza çözüldü",
        description: `${selectedAriza.id} ID'li arıza başarıyla çözüldü.${selectedMalzemeler.length > 0 ? " Kullanılan malzemeler envanterden düşüldü." : ""}`,
      })
      setIsCompletionDialogOpen(false)
      setSelectedAriza(null)
      setSelectedMalzemeler([])
    }, 1000)
  }

  return (
    <div className="container mx-auto p-6">
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold">Arıza Yönetimi</h1>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <Button onClick={() => setIsDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Yeni Arıza Bildirimi
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Yeni Arıza Bildirimi</DialogTitle>
            <DialogDescription>
              Tesislerde tespit ettiğiniz arızaları bildirmek için bu formu doldurun.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tesisId">Tesis</Label>
                  <Select onValueChange={handleTesisChange} defaultValue={form.getValues("tesisId")}>
                    <SelectTrigger id="tesisId">
                      <SelectValue placeholder="Tesis seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {tesisler.map((tesis) => (
                        <SelectItem key={tesis.id} value={tesis.id}>
                          {tesis.ad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.tesisId && (
                    <p className="text-sm text-red-500">{form.formState.errors.tesisId.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ekipmanId">Ekipman</Label>
                  <Select
                    onValueChange={(value) => form.setValue("ekipmanId", value)}
                    defaultValue={form.getValues("ekipmanId")}
                    disabled={!form.getValues("tesisId")}
                  >
                    <SelectTrigger id="ekipmanId">
                      <SelectValue placeholder="Ekipman seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredEkipmanlar.map((ekipman) => (
                        <SelectItem key={ekipman.id} value={ekipman.id}>
                          {ekipman.ad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.ekipmanId && (
                    <p className="text-sm text-red-500">{form.formState.errors.ekipmanId.message}</p>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="arizaTuru">Arıza Türü</Label>
                  <Select
                    onValueChange={(value) => form.setValue("arizaTuru", value)}
                    defaultValue={form.getValues("arizaTuru")}
                  >
                    <SelectTrigger id="arizaTuru">
                      <SelectValue placeholder="Arıza türü seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {arizaTurleri.map((tur) => (
                        <SelectItem key={tur} value={tur}>
                          {tur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.arizaTuru && (
                    <p className="text-sm text-red-500">{form.formState.errors.arizaTuru.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="oncelik">Öncelik</Label>
                  <Select
                    onValueChange={(value) => form.setValue("oncelik", value)}
                    defaultValue={form.getValues("oncelik")}
                  >
                    <SelectTrigger id="oncelik">
                      <SelectValue placeholder="Öncelik seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {oncelikSeviyeleri.map((seviye) => (
                        <SelectItem key={seviye.id} value={seviye.id}>
                          {seviye.ad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {form.formState.errors.oncelik && (
                    <p className="text-sm text-red-500">{form.formState.errors.oncelik.message}</p>
                  )}
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="bildirimTarihi">Bildirim Tarihi</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {form.getValues("bildirimTarihi") ? (
                        format(form.getValues("bildirimTarihi"), "PPP", { locale: tr })
                      ) : (
                        <span>Tarih seçin</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={form.getValues("bildirimTarihi")}
                      onSelect={(date) => form.setValue("bildirimTarihi", date)}
                      initialFocus
                      locale={tr}
                    />
                  </PopoverContent>
                </Popover>
                {form.formState.errors.bildirimTarihi && (
                  <p className="text-sm text-red-500">{form.formState.errors.bildirimTarihi.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="aciklama">Arıza Açıklaması</Label>
                <Textarea
                  id="aciklama"
                  placeholder="Arızayı detaylı bir şekilde açıklayın"
                  {...form.register("aciklama")}
                />
                {form.formState.errors.aciklama && (
                  <p className="text-sm text-red-500">{form.formState.errors.aciklama.message}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="dosya">Fotoğraf/Dosya Ekle (Opsiyonel)</Label>
                <div className="flex items-center gap-2">
                  <Input id="dosya" type="file" onChange={handleFileChange} className="flex-1" />
                  {selectedFile && <p className="text-sm text-muted-foreground">{selectedFile.name}</p>}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Gönderiliyor...
                  </>
                ) : (
                  "Arıza Bildir"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>

    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="tum-arizalar">Tüm Arızalar</TabsTrigger>
        <TabsTrigger value="bekleyen-arizalar">Bekleyen Arızalar</TabsTrigger>
        <TabsTrigger value="cozulen-arizalar">Çözülen Arızalar</TabsTrigger>
      </TabsList>

      <TabsContent value="tum-arizalar">
        <Card>
          <CardHeader>
            <CardTitle>Arıza Listesi</CardTitle>
            <CardDescription>Sistemde kayıtlı tüm arıza bildirimleri ve durumları</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Arıza ara..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Durum Filtresi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tumu">Tüm Durumlar</SelectItem>
                    {durumSeviyeleri.map((durum) => (
                      <SelectItem key={durum.id} value={durum.id}>
                        {durum.ad}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Öncelik Filtresi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tumu">Tüm Öncelikler</SelectItem>
                    {oncelikSeviyeleri.map((oncelik) => (
                      <SelectItem key={oncelik.id} value={oncelik.id}>
                        {oncelik.ad}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Arıza ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>Arıza Türü</TableHead>
                    <TableHead>Bildirim Tarihi</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Öncelik</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredArizalar.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        Arıza kaydı bulunamadı
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredArizalar.map((ariza) => (
                      <TableRow key={ariza.id}>
                        <TableCell className="font-medium">{ariza.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{ariza.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{ariza.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{ariza.arizaTuru}</TableCell>
                        <TableCell>{new Date(ariza.bildirimTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{renderStatusBadge(ariza.durum)}</TableCell>
                        <TableCell>{renderPriorityBadge(ariza.oncelik)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menü</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleShowDetail(ariza)}>
                                Detayları Görüntüle
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => {
                                toast({
                                  title: "Durum güncelleniyor",
                                  description: `${ariza.id} ID'li arızanın durumu güncelleniyor.`,
                                });
                                // Simüle edilmiş güncelleme işlemi
                                setTimeout(() => {
                                  toast({
                                    title: "Durum güncellendi",
                                    description: `${ariza.id} ID'li arızanın durumu başarıyla güncellendi.`,
                                  });
                                }, 1000);
                              }}>
                                Durumu Güncelle
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {
                                toast({
                                  title: "Teknisyen atanıyor",
                                  description: `${ariza.id} ID'li arızaya teknisyen atanıyor.`,
                                });
                                // Simüle edilmiş atama işlemi
                                setTimeout(() => {
                                  toast({
                                    title: "Teknisyen atandı",
                                    description: `${ariza.id} ID'li arızaya teknisyen başarıyla atandı.`,
                                  });
                                }, 1000);
                              }}>
                                Teknisyen Ata
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handlePlanMaintenance(ariza)}>
                                Bakım Planla
                              </DropdownMenuItem>
                              {ariza.durum !== "Çözüldü" && (
                                <DropdownMenuItem onClick={() => {
                                  setSelectedAriza(ariza);
                                  setIsCompletionDialogOpen(true);
                                }}>
                                  Arızayı Çöz
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="bekleyen-arizalar">
        <Card>
          <CardHeader>
            <CardTitle>Bekleyen Arızalar</CardTitle>
            <CardDescription>Çözüm bekleyen arıza bildirimleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Arıza ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>Arıza Türü</TableHead>
                    <TableHead>Bildirim Tarihi</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Öncelik</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {arizalar
                    .filter((ariza) => ["Beklemede", "İncelemede", "İşlemde"].includes(ariza.durum))
                    .map((ariza) => (
                      <TableRow key={ariza.id}>
                        <TableCell className="font-medium">{ariza.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{ariza.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{ariza.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{ariza.arizaTuru}</TableCell>
                        <TableCell>{new Date(ariza.bildirimTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{renderStatusBadge(ariza.durum)}</TableCell>
                        <TableCell>{renderPriorityBadge(ariza.oncelik)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menü</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleShowDetail(ariza)}>
                                Detayları Görüntüle
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => {
                                toast({
                                  title: "Durum güncelleniyor",
                                  description: `${ariza.id} ID'li arızanın durumu güncelleniyor.`,
                                });
                                // Simüle edilmiş güncelleme işlemi
                                setTimeout(() => {
                                  toast({
                                    title: "Durum güncellendi",
                                    description: `${ariza.id} ID'li arızanın durumu başarıyla güncellendi.`,
                                  });
                                }, 1000);
                              }}>
                                Durumu Güncelle
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {
                                toast({
                                  title: "Teknisyen atanıyor",
                                  description: `${ariza.id} ID'li arızaya teknisyen atanıyor.`,
                                });
                                // Simüle edilmiş atama işlemi
                                setTimeout(() => {
                                  toast({
                                    title: "Teknisyen atandı",
                                    description: `${ariza.id} ID'li arızaya teknisyen başarıyla atandı.`,
                                  });
                                }, 1000);
                              }}>
                                Teknisyen Ata
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handlePlanMaintenance(ariza)}>
                                Bakım Planla
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => {
                                setSelectedAriza(ariza);
                                setIsCompletionDialogOpen(true);
                              }}>
                                Arızayı Çöz
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="cozulen-arizalar">
        <Card>
          <CardHeader>
            <CardTitle>Çözülen Arızalar</CardTitle>
            <CardDescription>Çözüme kavuşturulmuş arıza bildirimleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className=\"rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">Arıza ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>Arıza Türü</TableHead>
                    <TableHead>Bildirim Tarihi</TableHead>
                    <TableHead>Çözüm Tarihi</TableHead>
                    <TableHead>Çözen Kişi</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {arizalar
                    .filter((ariza) => ariza.durum === "Çözüldü")
                    .map((ariza) => (
                      <TableRow key={ariza.id}>
                        <TableCell className="font-medium">{ariza.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{ariza.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{ariza.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{ariza.arizaTuru}</TableCell>
                        <TableCell>{new Date(ariza.bildirimTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{new Date().toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{ariza.atananKisi}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleShowDetail(ariza)}>
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Menü</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>

    {/* Arıza Detay Diyaloğu */}
    {selectedAriza && (
      <Dialog open={!!selectedAriza && !isCompletionDialogOpen && !isBakimDialogOpen} onOpenChange={() => setSelectedAriza(null)}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Arıza Detayları - {selectedAriza.id}</DialogTitle>
            <DialogDescription>Arıza bildirimi detaylı bilgileri ve durum güncellemesi</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Tesis</h3>
                <p>{selectedAriza.tesisAdi}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Ekipman</h3>
                <p>{selectedAriza.ekipmanAdi}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Arıza Türü</h3>
                <p>{selectedAriza.arizaTuru}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Bildirim Tarihi</h3>
                <p>{new Date(selectedAriza.bildirimTarihi).toLocaleDateString("tr-TR")}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Durum</h3>
                <p>{renderStatusBadge(selectedAriza.durum)}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Öncelik</h3>
                <p>{renderPriorityBadge(selectedAriza.oncelik)}</p>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-1">Arıza Açıklaması</h3>
              <p className="text-sm">{selectedAriza.aciklama}</p>
            </div>
            {selectedAriza.cozumNotu && (
              <div>
                <h3 className="text-sm font-medium mb-1">Çözüm Notu</h3>
                <p className="text-sm">{selectedAriza.cozumNotu}</p>
              </div>
            )}
            {selectedAriza.durum !== "Çözüldü" && (
              <div className="space-y-2 mt-4">
                <h3 className="text-sm font-medium">Durum Güncelleme</h3>
                <Select defaultValue={selectedAriza.durum.toLowerCase()}>
                  <SelectTrigger>
                    <SelectValue placeholder="Durum seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {durumSeviyeleri.map((durum) => (
                      <SelectItem key={durum.id} value={durum.id}>
                        {durum.ad}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Textarea placeholder="Çözüm notu veya açıklama ekleyin..." className="mt-2" />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedAriza(null)}>
              Kapat
            </Button>
            {selectedAriza.durum !== "Çözüldü" && (
              <div className="flex gap-2">
                <Button 
                  variant="outline"
                  onClick={() => {
                    setIsBakimDialogOpen(true);
                  }}
                >
                  Bakım Planla
                </Button>
                <Button
                  onClick={() => {
                    setIsCompletionDialogOpen(true);
                  }}
                >
                  Arızayı Çöz
                </Button>
              </div>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    )}

    {/* Bakım Planlama Diyaloğu */}
    {selectedAriza && (
      <Dialog open={isBakimDialogOpen} onOpenChange={setIsBakimDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Bakım Planla - {selectedAriza.id}</DialogTitle>
            <DialogDescription>{selectedAriza.ekipmanAdi} için bakım planlaması yapın.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBakimSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bakimTuru">Bakım Türü</Label>
                  <Select defaultValue={bakimTurleri[0]}>
                    <SelectTrigger id="bakimTuru">
                      <SelectValue placeholder="Bakım türü seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {bakimTurleri.map((tur) => (
                        <SelectItem key={tur} value={tur}>
                          {tur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bakimTarihi">Bakım Tarihi</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        <span>Tarih seçin</span>
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        initialFocus
                        locale={tr}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="teknisyen">Atanan Teknisyen/Ekip</Label>
                <Select defaultValue="1">
                  <SelectTrigger id="teknisyen">
                    <SelectValue placeholder="Teknisyen seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {personel.map((kisi) => (
                      <SelectItem key={kisi.id} value={kisi.id}>
                        {kisi.ad} - {kisi.unvan}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="aciklama">Bakım Açıklaması</Label>
                <Textarea
                  id="aciklama"
                  placeholder="Bakım hakkında detaylı açıklama"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Kullanılacak Malzemeler</Label>
                <div className="border rounded-md p-3 space-y-3">
                  {malzemeler.map((malzeme) => (
                    <div key={malzeme.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id={`malzeme-${malzeme.id}`} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleMalzemeChange(malzeme.id, 1)
                            } else {
                              handleMalzemeChange(malzeme.id, 0)
                            }
                          }}
                        />
                        <Label htmlFor={`malzeme-${malzeme.id}`} className="font-normal">
                          {malzeme.ad} (Stok: {malzeme.stok} {malzeme.birim})
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor={`miktar-${malzeme.id}`} className="text-sm">Miktar:</Label>
                        <Input
                          id={`miktar-${malzeme.id}`}
                          type="number"
                          className="w-20"
                          min="1"
                          max={malzeme.stok}
                          defaultValue="1"
                          onChange={(e) => handleMalzemeChange(malzeme.id, Number.parseInt(e.target.value) || 0)}
                          disabled={!selectedMalzemeler.some(m => m.id === malzeme.id)}
                        />
                      </div>
                    </div>
                  ))}
                  
                  {selectedMalzemeler.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <h4 className="text-sm font-medium mb-2">Seçilen Malzemeler:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedMalzemeler.map((malzeme) => (
                          <li key={malzeme.id}>
                            {malzeme.ad}: {malzeme.miktar} {malzeme.birim}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => {
                setIsBakimDialogOpen(false);
                setSelectedMalzemeler([]);
              }}>
                İptal
              </Button>
              <Button type="submit">Bakım Planla</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    )}

    {/* Arıza Tamamlama Diyaloğu */}
    {selectedAriza && (
      <Dialog open={isCompletionDialogOpen} onOpenChange={setIsCompletionDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Arıza Çözümü - {selectedAriza.id}</DialogTitle>
            <DialogDescription>{selectedAriza.ekipmanAdi} arızasını çözün.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCompletionSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tamamlanmaTarihi">Tamamlanma Tarihi</Label>
                  <Input id="tamamlanmaTarihi" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="teknisyen">Çözen Teknisyen</Label>
                  <Select defaultValue="1">
                    <SelectTrigger id="teknisyen">
                      <SelectValue placeholder="Teknisyen seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {personel.map((kisi) => (
                        <SelectItem key={kisi.id} value={kisi.id}>
                          {kisi.ad} - {kisi.unvan}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="cozumNotu">Çözüm Notu</Label>
                <Textarea
                  id="cozumNotu"
                  placeholder="Yapılan işlemler ve gözlemler hakkında not ekleyin"
                  rows={4}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Kullanılan Malzemeler</Label>
                <div className="border rounded-md p-3 space-y-3">
                  {malzemeler.map((malzeme) => (
                    <div key={malzeme.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id={`malzeme-${malzeme.id}`} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleMalzemeChange(malzeme.id, 1)
                            } else {
                              handleMalzemeChange(malzeme.id, 0)
                            }
                          }}
                        />
                        <Label htmlFor={`malzeme-${malzeme.id}`} className="font-normal">
                          {malzeme.ad} (Stok: {malzeme.stok} {malzeme.birim})
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor={`miktar-${malzeme.id}`} className="text-sm">Miktar:</Label>
                        <Input
                          id={`miktar-${malzeme.id}`}
                          type="number"
                          className="w-20"
                          min="1"
                          max={malzeme.stok}
                          defaultValue="1"
                          onChange={(e) => handleMalzemeChange(malzeme.id, Number.parseInt(e.target.value) || 0)}
                          disabled={!selectedMalzemeler.some(m => m.id === malzeme.id)}
                        />
                      </div>
                    </div>
                  ))}
                  
                  {selectedMalzemeler.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <h4 className="text-sm font-medium mb-2">Seçilen Malzemeler:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedMalzemeler.map((malzeme) => (
                          <li key={malzeme.id}>
                            {malzeme.ad}: {malzeme.miktar} {malzeme.birim}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="sonrakiIslem">Sonraki İşlem (Opsiyonel)</Label>
                <Select defaultValue="none">
                  <SelectTrigger id="sonrakiIslem">
                    <SelectValue placeholder="Sonraki işlem seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">İşlem Yok</SelectItem>
                    <SelectItem value="bakim">Bakım Planla</SelectItem>
                    <SelectItem value="kontrol">Kontrol Planla</SelectItem>
                    <SelectItem value="parca-degisimi">Parça Değişimi Planla</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => {
                setIsCompletionDialogOpen(false);
                setSelectedMalzemeler([]);
              }}>
                İptal
              </Button>
              <Button type="submit">Tamamla</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    )}
  </div>
  )
}
