"use client"

import { Calendar } from "@/components/ui/calendar"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Download,
  MoreHorizontal,
  Plus,
  Search,
  CheckCircle,
  Clock,
  AlertTriangle,
  FileText,
  CalendarIcon,
  Loader2,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { tr } from "date-fns/locale"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { format } from "date-fns"

// Örnek iş emri verileri
const isEmirleri = [
  {
    id: "IS-2023-001",
    tesisAdi: "Tesis 1",
    ekipmanAdi: "Üretim Hattı A - Konveyör",
    islemTuru: "Bakım",
    olusturmaTarihi: "2023-05-15T09:30:00",
    tamamlanmaTarihi: null,
    durum: "Açık",
    oncelik: "Yüksek",
    atananKisi: "Ahmet Yılmaz",
    aciklama: "Konveyör bandı bakımı yapılacak",
    tamamlanmaNotu: "",
  },
  {
    id: "IS-2023-002",
    tesisAdi: "Tesis 2",
    ekipmanAdi: "Paketleme Ünitesi",
    islemTuru: "Arıza Giderme",
    olusturmaTarihi: "2023-05-18T14:15:00",
    tamamlanmaTarihi: "2023-05-18T16:30:00",
    durum: "Tamamlandı",
    oncelik: "Kritik",
    atananKisi: "Mehmet Demir",
    aciklama: "Paketleme ünitesindeki elektrik arızası giderilecek",
    tamamlanmaNotu: "Elektrik arızası giderildi, sistem çalışır durumda.",
  },
  {
    id: "IS-2023-003",
    tesisAdi: "Tesis 1",
    ekipmanAdi: "Kompresör Ünitesi",
    islemTuru: "Kontrol",
    olusturmaTarihi: "2023-05-20T11:45:00",
    tamamlanmaTarihi: null,
    durum: "İşlemde",
    oncelik: "Orta",
    atananKisi: "Ali Kaya",
    aciklama: "Kompresör basınç kontrolü yapılacak",
    tamamlanmaNotu: "",
  },
  {
    id: "IS-2023-004",
    tesisAdi: "Tesis 3",
    ekipmanAdi: "Soğutma Sistemi",
    islemTuru: "Parça Değişimi",
    olusturmaTarihi: "2023-05-22T08:30:00",
    tamamlanmaTarihi: null,
    durum: "Açık",
    oncelik: "Düşük",
    atananKisi: "Ayşe Yıldız",
    aciklama: "Soğutma sistemi filtresi değiştirilecek",
    tamamlanmaNotu: "",
  },
  {
    id: "IS-2023-005",
    tesisAdi: "Tesis 2",
    ekipmanAdi: "Karıştırıcı Tank",
    islemTuru: "Temizlik",
    olusturmaTarihi: "2023-05-25T16:20:00",
    tamamlanmaTarihi: "2023-05-25T18:45:00",
    durum: "Tamamlandı",
    oncelik: "Orta",
    atananKisi: "Hasan Şahin",
    aciklama: "Karıştırıcı tank temizliği yapılacak",
    tamamlanmaNotu: "Tank temizliği tamamlandı, sistem çalışmaya hazır.",
  },
]

// Örnek tesisler
const tesisler = [
  { id: "1", ad: "Tesis 1" },
  { id: "2", ad: "Tesis 2" },
  { id: "3", ad: "Tesis 3" },
]

// Örnek ekipmanlar
const ekipmanlar = [
  { id: "1", tesisId: "1", ad: "Üretim Hattı A - Konveyör" },
  { id: "2", tesisId: "1", ad: "Kompresör Ünitesi" },
  { id: "3", tesisId: "1", ad: "Karıştırıcı Tank 1" },
  { id: "4", tesisId: "2", ad: "Paketleme Ünitesi" },
  { id: "5", tesisId: "2", ad: "Karıştırıcı Tank" },
  { id: "6", tesisId: "2", ad: "Üretim Hattı B" },
  { id: "7", tesisId: "3", ad: "Soğutma Sistemi" },
  { id: "8", tesisId: "3", ad: "Üretim Hattı C" },
  { id: "9", tesisId: "3", ad: "Depolama Ünitesi" },
]

// İşlem türleri
const islemTurleri = ["Bakım", "Arıza Giderme", "Kontrol", "Parça Değişimi", "Temizlik", "Kalibrasyon", "Diğer"]

// Öncelik seviyeleri
const oncelikSeviyeleri = [
  { id: "kritik", ad: "Kritik", renk: "destructive" },
  { id: "yuksek", ad: "Yüksek", renk: "destructive" },
  { id: "orta", ad: "Orta", renk: "warning" },
  { id: "dusuk", ad: "Düşük", renk: "secondary" },
]

// Durum seviyeleri
const durumSeviyeleri = [
  { id: "acik", ad: "Açık", renk: "secondary" },
  { id: "islemde", ad: "İşlemde", renk: "warning" },
  { id: "tamamlandi", ad: "Tamamlandı", renk: "success" },
  { id: "iptal", ad: "İptal", renk: "destructive" },
]

// Personel listesi
const personel = [
  { id: "1", ad: "Ahmet Yılmaz", unvan: "Teknisyen" },
  { id: "2", ad: "Mehmet Demir", unvan: "Teknisyen" },
  { id: "3", ad: "Ali Kaya", unvan: "Mühendis" },
  { id: "4", ad: "Ayşe Yıldız", unvan: "Teknisyen" },
  { id: "5", ad: "Hasan Şahin", unvan: "Mühendis" },
]

// Bakım türleri
const bakimTurleri = ["Periyodik Bakım", "Koruyucu Bakım", "Kestirimci Bakım", "Düzeltici Bakım", "Acil Bakım"]

// Arıza türleri
const arizaTurleri = ["Mekanik", "Elektrik", "Elektronik", "Hidrolik", "Pnömatik", "Sensör", "Yazılım", "Diğer"]

// Örnek malzemeler
const malzemeler = [
  { id: "M001", ad: "Yağlama Kiti", stok: 15, birim: "Adet" },
  { id: "M002", ad: "Filtre Seti", stok: 8, birim: "Adet" },
  { id: "M003", ad: "Sensör Modülü", stok: 5, birim: "Adet" },
  { id: "M004", ad: "Conta Takımı", stok: 20, birim: "Set" },
  { id: "M005", ad: "Motor Kayışı", stok: 12, birim: "Adet" },
  { id: "M006", ad: "Rulman", stok: 30, birim: "Adet" },
  { id: "M007", ad: "Hidrolik Yağ", stok: 50, birim: "Litre" },
]

export default function IsEmirleriPage() {
const [activeTab, setActiveTab] = useState("tum-is-emirleri")
const [searchTerm, setSearchTerm] = useState("")
const [isDialogOpen, setIsDialogOpen] = useState(false)
const [selectedIsEmri, setSelectedIsEmri] = useState(null)
const [isCompletionDialogOpen, setIsCompletionDialogOpen] = useState(false)
const [filteredEkipmanlar, setFilteredEkipmanlar] = useState([])
const [statusFilter, setStatusFilter] = useState("tumu")
const [priorityFilter, setPriorityFilter] = useState("tumu")
const { toast } = useToast()
const [isBakimDialogOpen, setIsBakimDialogOpen] = useState(false)
const [isArizaDialogOpen, setIsArizaDialogOpen] = useState(false)
const [selectedMalzemeler, setSelectedMalzemeler] = useState([])
const [bakimTarihi, setBakimTarihi] = useState(new Date())
const [isSubmitting, setIsSubmitting] = useState(false)

// Durum badgesi render fonksiyonu
const renderStatusBadge = (status) => {
  const durumSeviye = durumSeviyeleri.find((d) => d.ad === status)

  if (!durumSeviye) return <Badge>{status}</Badge>

  return <Badge variant={durumSeviye.renk}>{status}</Badge>
}

// Öncelik badgesi render fonksiyonu
const renderPriorityBadge = (priority) => {
  const oncelikSeviye = oncelikSeviyeleri.find((o) => o.ad === priority)

  if (!oncelikSeviye) return <Badge>{priority}</Badge>

  return <Badge variant={oncelikSeviye.renk}>{priority}</Badge>
}

// Filtreleme fonksiyonu
const filteredIsEmirleri = isEmirleri.filter((isEmri) => {
  // Arama terimi filtresi
  const searchMatch =
    isEmri.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    isEmri.tesisAdi.toLowerCase().includes(searchTerm.toLowerCase()) ||
    isEmri.ekipmanAdi.toLowerCase().includes(searchTerm.toLowerCase()) ||
    isEmri.aciklama.toLowerCase().includes(searchTerm.toLowerCase())

  // Durum filtresi
  const statusMatch = statusFilter === "tumu" || isEmri.durum.toLowerCase() === statusFilter.toLowerCase()

  // Öncelik filtresi
  const priorityMatch = priorityFilter === "tumu" || isEmri.oncelik.toLowerCase() === priorityFilter.toLowerCase()

  // Tab filtresi
  if (activeTab === "tum-is-emirleri") {
    return searchMatch && statusMatch && priorityMatch
  } else if (activeTab === "acik-is-emirleri") {
    return searchMatch && statusMatch && priorityMatch && isEmri.durum === "Açık"
  } else if (activeTab === "islemdeki-is-emirleri") {
    return searchMatch && statusMatch && priorityMatch && isEmri.durum === "İşlemde"
  } else if (activeTab === "tamamlanan-is-emirleri") {
    return searchMatch && statusMatch && priorityMatch && isEmri.durum === "Tamamlandı"
  }

  return searchMatch && statusMatch && priorityMatch
})

// Tesis değiştiğinde ekipmanları filtrele
const handleTesisChange = (tesisId) => {
  const filtered = ekipmanlar.filter((ekipman) => ekipman.tesisId === tesisId)
  setFilteredEkipmanlar(filtered)
}

// İş emri detayını gösterme işlevi
const handleShowDetail = (isEmri) => {
  setSelectedIsEmri(isEmri)
}

// İş emri başlatma işlevi
const handleStartWork = (isEmri) => {
  toast({
    title: "İş emri başlatılıyor",
    description: `${isEmri.id} ID'li iş emri başlatılıyor.`,
  })

  // Simüle edilmiş başlatma işlemi
  setTimeout(() => {
    toast({
      title: "İş emri başlatıldı",
      description: `${isEmri.id} ID'li iş emri başarıyla başlatıldı.`,
    })
  }, 1000)
}

// İş emri tamamlama işlevi
const handleCompleteWork = (isEmri) => {
  setSelectedIsEmri(isEmri)
  setIsCompletionDialogOpen(true)
}

// Bakım planlama işlevi
const handlePlanMaintenance = (isEmri) => {
  setSelectedIsEmri(isEmri)
  setIsBakimDialogOpen(true)
}

// Arıza bildirme işlevi
const handleReportFailure = (isEmri) => {
  setSelectedIsEmri(isEmri)
  setIsArizaDialogOpen(true)
}

// Malzeme seçimi işlevi
const handleMalzemeChange = (malzemeId, miktar) => {
  setSelectedMalzemeler(prev => {
    // Eğer malzeme zaten seçiliyse, miktarını güncelle
    const existingIndex = prev.findIndex(item => item.id === malzemeId)
    
    if (existingIndex >= 0) {
      // Miktar 0 ise malzemeyi listeden çıkar
      if (miktar === 0) {
        return prev.filter(item => item.id !== malzemeId)
      }
      
      // Miktarı güncelle
      const updated = [...prev]
      updated[existingIndex] = { ...updated[existingIndex], miktar }
      return updated
    } else if (miktar > 0) {
      // Yeni malzeme ekle
      const malzeme = malzemeler.find(m => m.id === malzemeId)
      return [...prev, { id: malzemeId, ad: malzeme.ad, miktar, birim: malzeme.birim }]
    }
    
    return prev
  })
}

// Bakım planlama form gönderimi
const handleBakimSubmit = (e) => {
  e.preventDefault()
  setIsSubmitting(true)
  
  // Seçilen malzemeleri kontrol et
  if (selectedMalzemeler.length > 0) {
    // Envanter güncellemesi
    const updatedMalzemeler = malzemeler.map(malzeme => {
      const selectedMalzeme = selectedMalzemeler.find(sm => sm.id === malzeme.id)
      if (selectedMalzeme) {
        return {
          ...malzeme,
          stok: malzeme.stok - selectedMalzeme.miktar
        }
      }
      return malzeme
    })
    
    console.log("Güncellenen envanter:", updatedMalzemeler)
  }

  toast({
    title: "Bakım planlanıyor",
    description: `${selectedIsEmri.id} - ${selectedIsEmri.ekipmanAdi} için bakım planlanıyor.`,
  })

  // Simüle edilmiş işlem
  setTimeout(() => {
    toast({
      title: "Bakım planlandı",
      description: `${selectedIsEmri.id} - ${selectedIsEmri.ekipmanAdi} için bakım başarıyla planlandı.${selectedMalzemeler.length > 0 ? ' Malzemeler envanterden düşüldü.' : ''}`,
    })
    setIsBakimDialogOpen(false)
    setSelectedMalzemeler([])
    setIsSubmitting(false)
  }, 1500)
}

// Arıza bildirimi form gönderimi
const handleArizaSubmit = (e) => {
  e.preventDefault()
  setIsSubmitting(true)
  
  // Seçilen malzemeleri kontrol et
  if (selectedMalzemeler.length > 0) {
    // Envanter güncellemesi
    const updatedMalzemeler = malzemeler.map(malzeme => {
      const selectedMalzeme = selectedMalzemeler.find(sm => sm.id === malzeme.id)
      if (selectedMalzeme) {
        return {
          ...malzeme,
          stok: malzeme.stok - selectedMalzeme.miktar
        }
      }
      return malzeme
    })
    
    console.log("Güncellenen envanter:", updatedMalzemeler)
  }

  toast({
    title: "Arıza bildiriliyor",
    description: `${selectedIsEmri.id} - ${selectedIsEmri.ekipmanAdi} için arıza bildirimi oluşturuluyor.`,
  })

  // Simüle edilmiş işlem
  setTimeout(() => {
    toast({
      title: "Arıza bildirildi",
      description: `${selectedIsEmri.id} - ${selectedIsEmri.ekipmanAdi} için arıza bildirimi başarıyla oluşturuldu.${selectedMalzemeler.length > 0 ? ' Malzemeler envanterden düşüldü.' : ''}`,
    })
    setIsArizaDialogOpen(false)
    setSelectedMalzemeler([])
    setIsSubmitting(false)
  }, 1500)
}

// İş emri tamamlama formu gönderimi
const handleCompletionSubmit = (e) => {
  e.preventDefault()
  setIsSubmitting(true)
  
  // Seçilen malzemeleri kontrol et
  if (selectedMalzemeler.length > 0) {
    // Envanter güncellemesi
    const updatedMalzemeler = malzemeler.map(malzeme => {
      const selectedMalzeme = selectedMalzemeler.find(sm => sm.id === malzeme.id)
      if (selectedMalzeme) {
        return {
          ...malzeme,
          stok: malzeme.stok - selectedMalzeme.miktar
        }
      }
      return malzeme
    })
    
    console.log("Güncellenen envanter:", updatedMalzemeler)
  }

  toast({
    title: "İş emri tamamlanıyor",
    description: `${selectedIsEmri.id} ID'li iş emri tamamlanıyor.`,
  })

  // Simüle edilmiş tamamlama işlemi
  setTimeout(() => {
    toast({
      title: "İş emri tamamlandı",
      description: `${selectedIsEmri.id} ID'li iş emri başarıyla tamamlandı.${selectedMalzemeler.length > 0 ? ' Kullanılan malzemeler envanterden düşüldü.' : ''}`,
    })
    setIsCompletionDialogOpen(false)
    setSelectedIsEmri(null)
    setSelectedMalzemeler([])
    setIsSubmitting(false)
  }, 1000)
}

// Yeni iş emri ekleme işlevi
const handleAddWorkOrder = (e) => {
  e.preventDefault()
  setIsSubmitting(true)

  toast({
    title: "İş emri oluşturuluyor",
    description: "Yeni iş emri oluşturuluyor.",
  })

  // Simüle edilmiş ekleme işlemi
  setTimeout(() => {
    toast({
      title: "İş emri oluşturuldu",
      description: "Yeni iş emri başarıyla oluşturuldu.",
    })
    setIsDialogOpen(false)
    setIsSubmitting(false)
  }, 1000)
}

// Rapor indirme işlevi
const handleDownloadReport = () => {
  toast({
    title: "Rapor indiriliyor",
    description: "İş emirleri raporu hazırlanıyor ve indirilecek.",
  })

  // Simüle edilmiş indirme işlemi
  setTimeout(() => {
    toast({
      title: "Rapor indirildi",
      description: "İş emirleri raporu başarıyla indirildi.",
    })
  }, 1500)
}

return (
  <div className="container mx-auto p-6">
    <div className="flex justify-between items-center mb-6">
      <h1 className="text-3xl font-bold">İş Emirleri Yönetimi</h1>
      <div className="flex gap-2">
        <Button variant="outline" onClick={handleDownloadReport}>
          <Download className="mr-2 h-4 w-4" />
          Rapor İndir
        </Button>
        <Button onClick={() => setIsDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Yeni İş Emri
        </Button>
      </div>
    </div>

    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Toplam İş Emri</CardTitle>
          <FileText className="h-4 w-4 text-blue-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{isEmirleri.length}</div>
          <p className="text-xs text-muted-foreground">Son 30 günde {isEmirleri.length} iş emri</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Açık İş Emirleri</CardTitle>
          <AlertTriangle className="h-4 w-4 text-purple-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{isEmirleri.filter((i) => i.durum === "Açık").length}</div>
          <p className="text-xs text-muted-foreground">Henüz başlatılmamış iş emirleri</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">İşlemdeki İş Emirleri</CardTitle>
          <Clock className="h-4 w-4 text-yellow-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{isEmirleri.filter((i) => i.durum === "İşlemde").length}</div>
          <p className="text-xs text-muted-foreground">Şu anda devam eden iş emirleri</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Tamamlanan İş Emirleri</CardTitle>
          <CheckCircle className="h-4 w-4 text-green-500" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{isEmirleri.filter((i) => i.durum === "Tamamlandı").length}</div>
          <p className="text-xs text-muted-foreground">Son 30 günde tamamlanan iş emirleri</p>
        </CardContent>
      </Card>
    </div>

    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="tum-is-emirleri">Tüm İş Emirleri</TabsTrigger>
        <TabsTrigger value="acik-is-emirleri">Açık</TabsTrigger>
        <TabsTrigger value="islemdeki-is-emirleri">İşlemde</TabsTrigger>
        <TabsTrigger value="tamamlanan-is-emirleri">Tamamlanan</TabsTrigger>
      </TabsList>

      <TabsContent value="tum-is-emirleri">
        <Card>
          <CardHeader>
            <CardTitle>İş Emirleri Listesi</CardTitle>
            <CardDescription>Sistemde kayıtlı tüm iş emirleri ve durumları</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="İş emri ara..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Durum Filtresi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tumu">Tüm Durumlar</SelectItem>
                    {durumSeviyeleri.map((durum) => (
                      <SelectItem key={durum.id} value={durum.id}>
                        {durum.ad}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Öncelik Filtresi" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tumu">Tüm Öncelikler</SelectItem>
                    {oncelikSeviyeleri.map((oncelik) => (
                      <SelectItem key={oncelik.id} value={oncelik.id}>
                        {oncelik.ad}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">İş Emri ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>İşlem Türü</TableHead>
                    <TableHead>Oluşturma Tarihi</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Öncelik</TableHead>
                    <TableHead>Atanan Kişi</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIsEmirleri.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-4">
                        İş emri kaydı bulunamadı
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredIsEmirleri.map((isEmri) => (
                      <TableRow key={isEmri.id}>
                        <TableCell className="font-medium">{isEmri.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{isEmri.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{isEmri.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{isEmri.islemTuru}</TableCell>
                        <TableCell>{new Date(isEmri.olusturmaTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{renderStatusBadge(isEmri.durum)}</TableCell>
                        <TableCell>{renderPriorityBadge(isEmri.oncelik)}</TableCell>
                        <TableCell>{isEmri.atananKisi}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Menü</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>İşlemler</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => handleShowDetail(isEmri)}>
                                Detayları Görüntüle
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {isEmri.durum === "Açık" && (
                                <DropdownMenuItem onClick={() => handleStartWork(isEmri)}>
                                  İşi Başlat
                                </DropdownMenuItem>
                              )}
                              {isEmri.durum === "İşlemde" && (
                                <DropdownMenuItem onClick={() => handleCompleteWork(isEmri)}>
                                  İşi Tamamla
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                onClick={() => {
                                  toast({
                                    title: "İş emri iptal ediliyor",
                                    description: `${isEmri.id} ID'li iş emri iptal ediliyor.`,
                                  })
                                }}
                              >
                                İşi İptal Et
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => handlePlanMaintenance(isEmri)}>
                                Bakım Planla
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleReportFailure(isEmri)}>
                                Arıza Bildir
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="acik-is-emirleri">
        <Card>
          <CardHeader>
            <CardTitle>Açık İş Emirleri</CardTitle>
            <CardDescription>Henüz başlatılmamış iş emirleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">İş Emri ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>İşlem Türü</TableHead>
                    <TableHead>Oluşturma Tarihi</TableHead>
                    <TableHead>Öncelik</TableHead>
                    <TableHead>Atanan Kişi</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIsEmirleri.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        Açık iş emri kaydı bulunamadı
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredIsEmirleri.map((isEmri) => (
                      <TableRow key={isEmri.id}>
                        <TableCell className="font-medium">{isEmri.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{isEmri.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{isEmri.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{isEmri.islemTuru}</TableCell>
                        <TableCell>{new Date(isEmri.olusturmaTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{renderPriorityBadge(isEmri.oncelik)}</TableCell>
                        <TableCell>{isEmri.atananKisi}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleStartWork(isEmri)}>
                            Başlat
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="islemdeki-is-emirleri">
        <Card>
          <CardHeader>
            <CardTitle>İşlemdeki İş Emirleri</CardTitle>
            <CardDescription>Şu anda devam eden iş emirleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">İş Emri ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>İşlem Türü</TableHead>
                    <TableHead>Başlangıç Tarihi</TableHead>
                    <TableHead>Öncelik</TableHead>
                    <TableHead>Atanan Kişi</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIsEmirleri.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        İşlemdeki iş emri kaydı bulunamadı
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredIsEmirleri.map((isEmri) => (
                      <TableRow key={isEmri.id}>
                        <TableCell className="font-medium">{isEmri.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{isEmri.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{isEmri.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{isEmri.islemTuru}</TableCell>
                        <TableCell>{new Date(isEmri.olusturmaTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>{renderPriorityBadge(isEmri.oncelik)}</TableCell>
                        <TableCell>{isEmri.atananKisi}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="outline" size="sm" onClick={() => handleCompleteWork(isEmri)}>
                            Tamamla
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="tamamlanan-is-emirleri">
        <Card>
          <CardHeader>
            <CardTitle>Tamamlanan İş Emirleri</CardTitle>
            <CardDescription>Tamamlanmış iş emirleri</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[100px]">İş Emri ID</TableHead>
                    <TableHead>Tesis/Ekipman</TableHead>
                    <TableHead>İşlem Türü</TableHead>
                    <TableHead>Oluşturma Tarihi</TableHead>
                    <TableHead>Tamamlanma Tarihi</TableHead>
                    <TableHead>Atanan Kişi</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIsEmirleri.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        Tamamlanan iş emri kaydı bulunamadı
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredIsEmirleri.map((isEmri) => (
                      <TableRow key={isEmri.id}>
                        <TableCell className="font-medium">{isEmri.id}</TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{isEmri.tesisAdi}</div>
                            <div className="text-sm text-muted-foreground">{isEmri.ekipmanAdi}</div>
                          </div>
                        </TableCell>
                        <TableCell>{isEmri.islemTuru}</TableCell>
                        <TableCell>{new Date(isEmri.olusturmaTarihi).toLocaleDateString("tr-TR")}</TableCell>
                        <TableCell>
                          {isEmri.tamamlanmaTarihi
                            ? new Date(isEmri.tamamlanmaTarihi).toLocaleDateString("tr-TR")
                            : "-"}
                        </TableCell>
                        <TableCell>{isEmri.atananKisi}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleShowDetail(isEmri)}>
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Menü</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>

    {/* İş Emri Detay Diyaloğu */}
    {selectedIsEmri && (
      <Dialog 
        open={!!selectedIsEmri && !isCompletionDialogOpen && !isBakimDialogOpen && !isArizaDialogOpen} 
        onOpenChange={() => setSelectedIsEmri(null)}
      >
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>İş Emri Detayları - {selectedIsEmri.id}</DialogTitle>
            <DialogDescription>İş emri detaylı bilgileri ve durum güncellemesi</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Tesis</h3>
                <p>{selectedIsEmri.tesisAdi}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Ekipman</h3>
                <p>{selectedIsEmri.ekipmanAdi}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">İşlem Türü</h3>
                <p>{selectedIsEmri.islemTuru}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Oluşturma Tarihi</h3>
                <p>{new Date(selectedIsEmri.olusturmaTarihi).toLocaleDateString("tr-TR")}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Durum</h3>
                <p>{renderStatusBadge(selectedIsEmri.durum)}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Öncelik</h3>
                <p>{renderPriorityBadge(selectedIsEmri.oncelik)}</p>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-1">Atanan Kişi</h3>
              <p>{selectedIsEmri.atananKisi}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-1">Açıklama</h3>
              <p className="text-sm">{selectedIsEmri.aciklama}</p>
            </div>
            {selectedIsEmri.tamamlanmaNotu && (
              <div>
                <h3 className="text-sm font-medium mb-1">Tamamlanma Notu</h3>
                <p className="text-sm">{selectedIsEmri.tamamlanmaNotu}</p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedIsEmri(null)}>
              Kapat
            </Button>
            {selectedIsEmri.durum === "Açık" && (
              <Button onClick={() => handleStartWork(selectedIsEmri)}>İşi Başlat</Button>
            )}
            {selectedIsEmri.durum === "İşlemde" && (
              <Button onClick={() => handleCompleteWork(selectedIsEmri)}>İşi Tamamla</Button>
            )}
            {(selectedIsEmri.durum === "Açık" || selectedIsEmri.durum === "İşlemde") && (
              <div className="flex gap-2">
                <Button 
                  variant="outline"
                  onClick={() => handlePlanMaintenance(selectedIsEmri)}
                >
                  Bakım Planla
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => handleReportFailure(selectedIsEmri)}
                >
                  Arıza Bildir
                </Button>
              </div>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    )}

    {/* Bakım Planlama Diyaloğu */}
    {selectedIsEmri && (
      <Dialog open={isBakimDialogOpen} onOpenChange={setIsBakimDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Bakım Planla - {selectedIsEmri.id}</DialogTitle>
            <DialogDescription>{selectedIsEmri.ekipmanAdi} için bakım planlaması yapın.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleBakimSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bakimTuru">Bakım Türü</Label>
                  <Select defaultValue={bakimTurleri[0]}>
                    <SelectTrigger id="bakimTuru">
                      <SelectValue placeholder="Bakım türü seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {bakimTurleri.map((tur) => (
                        <SelectItem key={tur} value={tur}>
                          {tur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bakimTarihi">Bakım Tarihi</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant={"outline"} className="w-full justify-start text-left font-normal">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {bakimTarihi ? format(bakimTarihi, "PPP", { locale: tr }) : <span>Tarih seçin</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={bakimTarihi}
                        onSelect={setBakimTarihi}
                        initialFocus
                        locale={tr}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="teknisyen">Atanan Teknisyen/Ekip</Label>
                <Select defaultValue="1">
                  <SelectTrigger id="teknisyen">
                    <SelectValue placeholder="Teknisyen seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {personel.map((kisi) => (
                      <SelectItem key={kisi.id} value={kisi.id}>
                        {kisi.ad} - {kisi.unvan}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="aciklama">Bakım Açıklaması</Label>
                <Textarea
                  id="aciklama"
                  placeholder="Bakım hakkında detaylı açıklama"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Kullanılacak Malzemeler</Label>
                <div className="border rounded-md p-3 space-y-3">
                  {malzemeler.map((malzeme) => (
                    <div key={malzeme.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id={`malzeme-${malzeme.id}`} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleMalzemeChange(malzeme.id, 1)
                            } else {
                              handleMalzemeChange(malzeme.id, 0)
                            }
                          }}
                        />
                        <Label htmlFor={`malzeme-${malzeme.id}`} className="font-normal">
                          {malzeme.ad} (Stok: {malzeme.stok} {malzeme.birim})
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor={`miktar-${malzeme.id}`} className="text-sm">Miktar:</Label>
                        <Input
                          id={`miktar-${malzeme.id}`}
                          type="number"
                          className="w-20"
                          min="1"
                          max={malzeme.stok}
                          defaultValue="1"
                          onChange={(e) => handleMalzemeChange(malzeme.id, Number.parseInt(e.target.value) || 0)}
                          disabled={!selectedMalzemeler.some(m => m.id === malzeme.id)}
                        />
                      </div>
                    </div>
                  ))}
                  
                  {selectedMalzemeler.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <h4 className="text-sm font-medium mb-2">Seçilen Malzemeler:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedMalzemeler.map((malzeme) => (
                          <li key={malzeme.id}>
                            {malzeme.ad}: {malzeme.miktar} {malzeme.birim}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => {
                setIsBakimDialogOpen(false);
                setSelectedMalzemeler([]);
              }}>
                İptal
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    İşleniyor...
                  </>
                ) : (
                  "Bakım Planla"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    )}

    {/* Arıza Bildirimi Diyaloğu */}
    {selectedIsEmri && (
      <Dialog open={isArizaDialogOpen} onOpenChange={setIsArizaDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Arıza Bildir - {selectedIsEmri.id}</DialogTitle>
            <DialogDescription>{selectedIsEmri.ekipmanAdi} için arıza bildirimi oluşturun.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleArizaSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="arizaTuru">Arıza Türü</Label>
                  <Select defaultValue="Mekanik">
                    <SelectTrigger id="arizaTuru">
                      <SelectValue placeholder="Arıza türü seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {arizaTurleri.map((tur) => (
                        <SelectItem key={tur} value={tur}>
                          {tur}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="oncelik">Öncelik</Label>
                  <Select defaultValue="yuksek">
                    <SelectTrigger id="oncelik">
                      <SelectValue placeholder="Öncelik seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {oncelikSeviyeleri.map((seviye) => (
                        <SelectItem key={seviye.id} value={seviye.id}>
                          {seviye.ad}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="teknisyen">Atanan Teknisyen</Label>
                <Select defaultValue="1">
                  <SelectTrigger id="teknisyen">
                    <SelectValue placeholder="Teknisyen seçin" />
                  </SelectTrigger>
                  <SelectContent>
                    {personel.map((kisi) => (
                      <SelectItem key={kisi.id} value={kisi.id}>
                        {kisi.ad} - {kisi.unvan}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="aciklama">Arıza Açıklaması</Label>
                <Textarea
                  id="aciklama"
                  placeholder="Arıza hakkında detaylı açıklama"
                  rows={3}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Kullanılacak Malzemeler</Label>
                <div className="border rounded-md p-3 space-y-3">
                  {malzemeler.map((malzeme) => (
                    <div key={malzeme.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id={`malzeme-${malzeme.id}`} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleMalzemeChange(malzeme.id, 1)
                            } else {
                              handleMalzemeChange(malzeme.id, 0)
                            }
                          }}
                        />
                        <Label htmlFor={`malzeme-${malzeme.id}`} className="font-normal">
                          {malzeme.ad} (Stok: {malzeme.stok} {malzeme.birim})
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor={`miktar-${malzeme.id}`} className="text-sm">Miktar:</Label>
                        <Input
                          id={`miktar-${malzeme.id}`}
                          type="number"
                          className="w-20"
                          min="1"
                          max={malzeme.stok}
                          defaultValue="1"
                          onChange={(e) => handleMalzemeChange(malzeme.id, Number.parseInt(e.target.value) || 0)}
                          disabled={!selectedMalzemeler.some(m => m.id === malzeme.id)}
                        />
                      </div>
                    </div>
                  ))}
                  
                  {selectedMalzemeler.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <h4 className="text-sm font-medium mb-2">Seçilen Malzemeler:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedMalzemeler.map((malzeme) => (
                          <li key={malzeme.id}>
                            {malzeme.ad}: {malzeme.miktar} {malzeme.birim}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => {
                setIsArizaDialogOpen(false);
                setSelectedMalzemeler([]);
              }}>
                İptal
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    İşleniyor...
                  </>
                ) : (
                  "Arıza Bildir"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    )}

    {/* İş Tamamlama Diyaloğu */}
    {selectedIsEmri && (
      <Dialog open={isCompletionDialogOpen} onOpenChange={setIsCompletionDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>İş Tamamla - {selectedIsEmri.id}</DialogTitle>
            <DialogDescription>{selectedIsEmri.islemTuru} işlemini tamamlayın.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCompletionSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tamamlanmaTarihi">Tamamlanma Tarihi</Label>
                  <Input id="tamamlanmaTarihi" type="date" defaultValue={new Date().toISOString().split("T")[0]} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="teknisyen">Tamamlayan Teknisyen</Label>
                  <Select defaultValue="1">
                    <SelectTrigger id="teknisyen">
                      <SelectValue placeholder="Teknisyen seçin" />
                    </SelectTrigger>
                    <SelectContent>
                      {personel.map((kisi) => (
                        <SelectItem key={kisi.id} value={kisi.id}>
                          {kisi.ad} - {kisi.unvan}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="tamamlanmaNotu">Tamamlanma Notu</Label>
                <Textarea
                  id="tamamlanmaNotu"
                  placeholder="Yapılan işlemler ve gözlemler hakkında not ekleyin"
                  rows={4}
                />
              </div>
              
              <div className="space-y-2">
                <Label>Kullanılan Malzemeler</Label>
                <div className="border rounded-md p-3 space-y-3">
                  {malzemeler.map((malzeme) => (
                    <div key={malzeme.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id={`malzeme-${malzeme.id}`} 
                          onCheckedChange={(checked) => {
                            if (checked) {
                              handleMalzemeChange(malzeme.id, 1)
                            } else {
                              handleMalzemeChange(malzeme.id, 0)
                            }
                          }}
                        />
                        <Label htmlFor={`malzeme-${malzeme.id}`} className="font-normal">
                          {malzeme.ad} (Stok: {malzeme.stok} {malzeme.birim})
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor={`miktar-${malzeme.id}`} className="text-sm">Miktar:</Label>
                        <Input
                          id={`miktar-${malzeme.id}`}
                          type="number"
                          className="w-20"
                          min="1"
                          max={malzeme.stok}
                          defaultValue="1"
                          onChange={(e) => handleMalzemeChange(malzeme.id, Number.parseInt(e.target.value) || 0)}
                          disabled={!selectedMalzemeler.some(m => m.id === malzeme.id)}
                        />
                      </div>
                    </div>
                  ))}
                  
                  {selectedMalzemeler.length > 0 && (
                    <div className="mt-3 pt-3 border-t">
                      <h4 className="text-sm font-medium mb-2">Seçilen Malzemeler:</h4>
                      <ul className="text-sm space-y-1">
                        {selectedM
